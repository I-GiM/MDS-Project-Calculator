import React from 'react';
const resultScreen = (props) => (
  <div className="result-screen">
    {props.children}
  </div>
);
export default resultScreen;
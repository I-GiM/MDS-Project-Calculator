import React from 'react';
const keypadRow = (props) => (
  <div className="keypad__row">
    {props.children}
  </div>
);
export default keypadRow;
import React from 'react';
import './styles/styles.css'; 
import Calculator from './layout/Calculator/calculator';


const app = () => (
  <div className="app">
    <Calculator />
  </div>
);



export default app;
